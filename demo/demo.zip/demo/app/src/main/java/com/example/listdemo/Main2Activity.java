package com.example.listdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {

    private List<Item> ItemList= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        inititem();
        ItemAdapter adapter=new ItemAdapter(Main2Activity.this,R.layout.item_item,ItemList);
        ListView listView= (ListView)findViewById(R.id.list_view);
        listView.setAdapter(adapter);

    }
    private void inititem(){
        for(int i=0;i<30;i=i+1){
            Item item=new Item("第"+i+"个数字");
            ItemList.add(item);
            //oast.makeText(Main2Activity.this,item.getName()+"",Toast.LENGTH_LONG).show();
        }
    }
}
